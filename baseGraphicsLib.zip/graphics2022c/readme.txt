To change the name of your project/executable:

    Edit CMakeLists.txt  and change the project name:
    
        project(myprojectname LANGUAGES CXX C)


Linux folks:

sudo apt install build-essential
sudo apt install libgl-dev
sudo apt install xorg-dev
sudo apt-get install freeglut3-dev
 
Qt:   

    Open CMakeLists.txt as CMake project

Visual Studio:   

    Open as CMakeLists.txt as CMake project

gcc/Command line:

    mkdir build
    cd build
    cmake ..
    make


